
import json
from urllib.parse import urljoin
import requests


def on_input(msg_id, header, body):

    
    # External Catalog Credentials and RestAPI
    host = api.config.http_connection['connectionProperties']['host']
    user = api.config.http_connection['connectionProperties']['user']
    pwd = api.config.http_connection['connectionProperties']['password']
    path = api.config.http_connection['connectionProperties']['path']

    # Conversion of di metadata json to external catalog API json
    metadata_json = body.get()
    #metadata = json.loads(metadata_json)

    # Calling RestAPI of external catalog
    url = urljoin(host, path)
    headers = {'X-Requested-With': 'XMLHttpRequest'}
    r = requests.post(url,headers=headers,data=metadata_json)

    
    # Send data to outport
    api.outputs.output.publish(metadata_json, header=header)


api.set_port_callback('input', on_input)