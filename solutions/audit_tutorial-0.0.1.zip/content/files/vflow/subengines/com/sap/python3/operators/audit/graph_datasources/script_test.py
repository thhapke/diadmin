import sys
import json
from os.path import dirname, join, abspath
import logging

import pandas as pd

logging.basicConfig(level=logging.INFO)

proj_dir = join(dirname(dirname(dirname(dirname(abspath(__file__))))))
sys.path.insert(0, proj_dir)

import script
from diadmin.dimockapi.mock_api import api

api.init(__file__)  # class instance of mock_api

# config parameter
with open(join('http_connections', 'http_connection_pipeline.json')) as fp:
    api.config.connection_id = json.load(fp)

df = pd.read_csv('tmp/graphs.csv')

tbl = api.Table(df.values.tolist(), "pipeline.runtime_graphs")
data = api.Message(tbl)

host = api.config.connection_id['connectionProperties']['host']
user = api.config.connection_id['connectionProperties']['user']
pwd = api.config.connection_id['connectionProperties']['password']
tenant = 'default'
header = {"com.sap.headers.batch": [0, True, 1, 0, ""],
          "audit.connection_http": [host, user, pwd, '', tenant]}

script.on_input(0, header, data)

for i, m in enumerate(api.msg_list):
    df = pd.DataFrame(m['msg'].get(), columns=['user', 'tenant', 'src', 'name', 'handle', 'status', 'submitted',
                                               'stopped', 'runtime', 'connection_id', 'type', 'path',
                                               'component', 'direction'])
    df.to_csv('tmp/graphs_sources.csv', index=False)
