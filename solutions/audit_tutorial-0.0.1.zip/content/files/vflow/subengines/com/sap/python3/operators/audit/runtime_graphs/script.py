import os
import json
from datetime import datetime

import requests
import pandas as pd

time_offset = 0


#
# get graphs of a use
#
def get_graphs(connection, user, offset):
    restapi = "/app/pipeline-modeler/service/v1/runtime/graphsquery"
    url = connection['url'] + restapi
    headers = {'x-requested-with': 'fetch', 'x-datahub-user': user}
    payload = {"filter": ["and", ["equal", "status", "completed"], ["greaterThan", "stopped", offset]]}
    r = requests.post(url, headers=headers, auth=connection['auth'], verify=True, data=json.dumps(payload))

    if r.status_code != 200:
        api.logger.error(f"Status code for user {user}: {r.status_code}  - {r.text}")
        return []

    graphs = list()
    for g in r.json():
        substitutions = json.dumps(g['configurationSubstitutions']) if 'configurationSubstitutions' in g else '{}'
        runtime = g['stopped'] - g['submitted']
        if runtime < 0:
            runtime = 0
        rec = {'user': g['user'], 'tenant': g['tenant'], 'src': g['src'], 'name': g['name'], 'handle': g['handle'],
               'status': g['status'], 'submitted': g['submitted'], 'stopped': g['stopped'], 'runtime': runtime,
               'substitutions': substitutions}
        graphs.append(rec)
    return graphs


#
# Callback of operator
#
def on_input(msg_id, header, data):
    global time_offset

    # prepare
    host = api.config.connection_id['connectionProperties']['host']
    user = api.config.connection_id['connectionProperties']['user']
    pwd = api.config.connection_id['connectionProperties']['password']
    tenant = os.environ.get('VSYSTEM_TENANT')
    if not tenant:
        api.logger.warning("No system variable \'VSYSTEM_TENANT\' set.")
        tenant = 'default'
    connection = {'url': host, 'auth': (tenant + '\\' + user, pwd)}
    users = data.get()

    if not users:
        return None

    # process
    graphs = list()
    for row in users.body:
        user_graphs = get_graphs(connection, row[1], time_offset)
        if user_graphs:
            graphs.extend(user_graphs)

    if not graphs:
        return None

    time_offset = max(graphs, key=lambda g: g['stopped'])['stopped']

    df = pd.DataFrame(graphs)

    # output
    header = {"com.sap.headers.batch": [0, True, 1, 0, ""],
              "audit.connection_http": [host, user, pwd, '', tenant]}

    # Sort the outcome
    v_ref = api.DataTypeReference("table", "audit.runtime_graphs")
    table_vtype = api.type_context.get_vtype(v_ref)
    column_names = list(table_vtype.columns.keys())
    df = df[column_names]

    tbl = api.Table(df.values.tolist(), "audit.runtime_graphs")

    api.outputs.output.publish(tbl, header=header)


api.set_port_callback("input", on_input)


api.set_initial_snapshot_info(api.InitialProcessInfo(is_stateful=True))


def serialize(epoch):
    return str(time_offset).encode()


api.set_serialize_callback(serialize)


def restore(epoch, last_time):
    global time_offset
    time_offset = int(last_time.decode())


api.set_restore_callback(restore)
