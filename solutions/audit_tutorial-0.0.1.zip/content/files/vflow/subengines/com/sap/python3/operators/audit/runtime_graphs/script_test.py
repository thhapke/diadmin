import sys
import json
from os.path import dirname, join, abspath
import logging
import time

import pandas as pd

logging.basicConfig(level=logging.INFO)

proj_dir = join(dirname(dirname(dirname(dirname(abspath(__file__))))))
sys.path.insert(0, proj_dir)

import script
from diadmin.dimockapi.mock_api import api

api.init(__file__)  # class instance of mock_api

# config parameter
with open(join('http_connections', 'http_connection_pipeline.json')) as fp:
    api.config.connection_id = json.load(fp)

df = pd.read_csv('tmp/users.csv')

tbl = api.Table(df.values.tolist(), "*")
data = api.Message(tbl)

header = [0, True, 1, 0, ""]
header = {"com.sap.headers.batch": header}

for t in range(0, 1):
    script.on_input(t, header, data)
    time.sleep(15)

for i, m in enumerate(api.msg_list):
    df = pd.DataFrame(m['msg'].get(), columns=['user', 'tenant', 'src', 'name', 'handle', 'status', 'submitted',
                                               'stopped', 'runtime', 'substitutions'])
    print(df)
    df.to_csv('tmp/graphs.csv', index=False)
