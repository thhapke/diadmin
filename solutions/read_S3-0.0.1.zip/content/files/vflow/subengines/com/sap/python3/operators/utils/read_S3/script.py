# Mock apis needs to be commented before used within SAP Data Intelligence
#from diadmin.dimockapi.mock_api import api

from os import path
import io
import pickle

import boto3

def gen():

    api.logger.info('Open S3 client')
    s3 = boto3.resource('s3',
                          aws_access_key_id=api.config.s3_connection["connectionProperties"]["accessKey"],
                          aws_secret_access_key=api.config.s3_connection["connectionProperties"]["secretKey"],
                          region_name=api.config.s3_connection["connectionProperties"]["region"])

    root_path = api.config.s3_connection["connectionProperties"]["rootPath"].split('/',1)
    bucket_name = root_path[0]
    if api.config.file[0] == '/':
        api.config.file = api.config.file[1:]
    if len(root_path) > 1:
        filename = path.join(root_path[1],api.config.file)
    bstream = io.BytesIO()

    bucket = s3.Bucket(bucket_name)
    object = bucket.Object(filename)
    object.download_fileobj(bstream)

    api.outputs.output.publish(bstream,-1,header=None)
    bstream.seek(0)
    
    
api.set_prestart(gen)