import sys
import json
import pickle
from os.path import dirname, join, abspath

import pandas as pd
import numpy as np
import logging

proj_dir = join(dirname(dirname(dirname(dirname(abspath(__file__))))))
sys.path.insert(0, proj_dir)

import script
from diadmin.dimockapi.mock_api import api
from diadmin.dimockapi.mock_inport import operator_test

logging.basicConfig(level=logging.INFO)

api.init(__file__)     # class instance of mock_api

optest = operator_test(__file__)

# config parameter
api.config.errorHandling = '{"type":"terminate on error"}' # type: string


with open('http_connections/pmroot.txt') as fp:
    s3access = json.load(fp)

api.config.s3_connection = {"connectionProperties":dict()}
api.config.s3_connection["connectionProperties"]["accessKey"] = s3access['access_key_id']
api.config.s3_connection["connectionProperties"]["secretKey"] = s3access['secret_access_key']
api.config.s3_connection["connectionProperties"]["region"] = s3access['region']
api.config.s3_connection["connectionProperties"]["rootPath"] = s3access['bucket'] + '/catalog'
api.config.file = '/ml/used_cars_price_prediction_model_20220411.pickle'

logging.info("Call Operator")
script.gen()

logging.info("Load Model")
model = pickle.load(api.msg_list[0]['msg'])

for p, v in model.get_params().items():
    print(f"{p}: {v}")

x_new = [[2005, 150, 80000]]
predictions = model.predict(x_new)
print(f"Price prediction: {round(predictions[0],2)}")

#logging.info("Read Data")
#df = pd.read_csv('/Users/Shared/data/ml/USEDCARS_40K.csv')

#logging.info("Predict")
#prediction = model.predict(df[['YEAROFREGISTRATION', 'HP', 'KILOMETER']].values)
#mse = np.mean((prediction - df[['PRICE']].values)**2, axis=0)
#rmse = np.sqrt(mse)
#rmse = round(np.sqrt(mse),2)

#print(f"RMSE: {rmse}  (#{df.shape[0]})")